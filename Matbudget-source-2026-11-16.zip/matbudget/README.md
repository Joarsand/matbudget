# Matbudget — submission source snapshot

Prepared 16 November 2026. Read PROJECT-DOCUMENTATION.md first for current scope,
verification and limitations. Older documents under docs/ record development
stages and can contain superseded figures.

Requires Node.js 22+. Run `node server.mjs`, then open http://127.0.0.1:8787/.
Run `node --test tests/*.test.mjs` for local tests (47 passed on preparation date).
AI needs separately configured AWS permissions and private server settings;
it is disabled by default. See .env.example. No secrets are included.

This source snapshot excludes private deployment state, runtime data, caches,
credentials, logs and machine-specific launchers. Imported live price files may
need regeneration. Fixture prices under tests/fixtures are test data only.
No GitHub source publication or current public availability is asserted here.
