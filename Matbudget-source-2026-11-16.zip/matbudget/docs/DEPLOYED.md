# Matbudget — deployed 9 November 2026

Public application: https://dw911x8c8grll.cloudfront.net/


## Current real-price status

The live price refresh now works: 57 reviewed observations across Willys Sköndal, Hemköp Torsplan and Mathem. The other ten chains are not connected. A four-times-daily refresh is enabled. See [REAL-PRICE-INTEGRATION.md](REAL-PRICE-INTEGRATION.md) for exact scope, price semantics and the remaining all-thirteen requirement.

## Earlier no-demo safeguard

Update on 9 November 2026: all synthetic regular/member prices and generated chain markups were removed from runtime data. No live price feed is connected yet. The UI shows missing prices, no basket total or budget percentage, and no cheapest-store badge for incomplete baskets. Shopping quantities remain usable; unverified store pack counts/leftovers are hidden. Synthetic arithmetic fixtures now exist only under tests/fixtures and are never served. The existing private AI configuration and persistent quota were preserved. 24 local tests plus local/public browser checks cover this change.

The original deployment record below describes the initial version; its references to demo prices are historical.

## Original verified outcome

- HTTPS responds 200 and CloudFront distribution status is Deployed.
- A real Bedrock request through the production app generated seven dinners.
- An isolated browser then generated a real 21-meal week through public HTTPS.
- Its shopping list, saved AI plan, mobile layout, protected API and private-file
  isolation passed. Two real AI attempts were used; no user browser plan was replaced.
- 21 local engine/API tests plus quiz, theme/recipes and controlled-AI browser
  checks passed. Live tests are explicitly marked because they consume AI usage.
- All prices remain fictional; AI selects among 50 authored recipes. A month
  repeats the generated seven-day menu. This is not live retailer price integration.

## Use

Open the URL, finish or skip the quiz, and scroll to **Planera med AI**. Enter the
private test access code from local ignored file `var/AI-ACCESS-CODE.txt`, select
AI, then press **Skapa min matplan**. The code is not saved by the browser.
Without AI selected the demo planner remains available. Model failure keeps the
previous plan and shows an error. Whole-pack cost, exclusions, stores and list
quantities are checked/calculated by code. An over-budget plan stays visibly
over budget rather than being falsely described as affordable.

The public origin has separate browser storage from localhost. Saved local
preferences are not automatically uploaded or migrated. AI requests submit the
chosen food-planning settings to this server/Bedrock, not passwords or AWS keys.

## Actual resources

Account: ACCOUNT_ID_REDACTED; EC2 region: eu-north-1.

| Resource | Identifier |
|---|---|
| EC2 Amazon Linux 2023, t3.micro, standard CPU credits | i-026095e88498b5fcc |
| Dedicated security group | sg-0bae394575553a1af |
| Elastic IPv4 | 13.63.152.184 |
| Elastic IP allocation | eipalloc-029832c5f369a1593 |
| CloudFront distribution | E9MJPTLCWMPM4 |
| EC2 role and instance profile | MatbudgetWebRole |
| Role inline policy | MatbudgetNovaMicro |
| joariam inline deployment policy | MatbudgetDeployment |

Storage is 8 GiB encrypted gp3 with DeleteOnTermination. IMDSv2 is required.
The role can invoke only Nova Micro via the Stockholm EU inference profile.
Inference can route within the EU; it is not guaranteed to stay in Sweden.
No S3 bucket, database, ALB or old coursework Terraform was deployed.

## Network and secrets

Visitors connect to CloudFront using HTTPS. CloudFront connects over HTTP to the
dedicated origin: this is **not end-to-end TLS**. Origin port 80 accepts only the
AWS CloudFront origin-facing prefix list, and nginx additionally requires a
random origin header. Direct public browsing by IP is deliberately unavailable.
SSH port 22 is restricted to the owner's deployment IP DEPLOYMENT_IP_REDACTED/32, not the
whole internet. Local service listens only on 127.0.0.1:8787.

Server configuration is root-readable `/etc/matbudget.env`; the app runs as
unprivileged `matbudget`. No long-lived personal AWS keys were copied to EC2.
AWS CLI uses temporary role credentials. The SSH host fingerprint was verified
against the AWS boot console before uploading. Temporary staged secret/archive
files were removed. Local `var/` holds ignored deployment state and private test
codes: do not publish, attach to a report or commit this directory.

## Limits and costs

20 model attempts per UTC day across the app, one in flight, ten-second cooldown,
1,600 output tokens/request and a persisted attempt counter. This is a prototype
single-process limit, not an account-wide financial cap. A public deployment
still needs login/user quotas before unrestricted use. Do not share its access
code publicly. A malformed model response consumes one attempt and is rejected.

The accepted initial allowance was roughly 160–280 SEK/month for small-server
operation plus light AI usage. This is not a fixed-price quote or guaranteed bill.
CloudFront has also been added for HTTPS; traffic charges are usage-dependent.
No budget alarm was created because no notification destination was chosen.
Check AWS Billing for exact usage, credits, VAT and current prices.

Stopping EC2 stops its instance compute charge, but **storage and the allocated
public IPv4 can continue to cost money**. CloudFront may still incur traffic
charges. A budget notification is not an automatic spending cap.

## Maintenance and handoff

Source: this `work/grocery-budget` folder. No GitHub repository was chosen or
published for this app yet. Old QA reports/repositories were not changed.

Connect with the existing Ubuntu `~/.ssh/ec2kp` and the separate verified
`~/.ssh/matbudget-known-hosts` file. User is `ec2-user`, host is the Elastic IP.
Read service status with `sudo systemctl status matbudget` and logs with
`sudo journalctl -u matbudget`. Never print or commit `/etc/matbudget.env`.

Preserve `/var/lib/matbudget/ai-usage.json` during updates; resetting it bypasses
the daily quota. Do not rerun the initial installer as an updater: it starts
with AI disabled. Upload changed source files and restart `matbudget` for code
updates, or nginx for proxy changes. CloudFront caching is disabled for the
prototype to avoid stale UI/API responses.

To pause: stop only instance i-026095e88498b5fcc. To resume: start that same
instance, wait for service readiness and verify the HTTPS URL; its Elastic IP
keeps the origin address stable. Confirm any destructive cleanup with the owner
and name these exact resources. Do not run old coursework Terraform destroy.
