# AI integration and AWS deployment — 9 November 2026

## Status update

Deployment and two live Bedrock generations are now verified. See [DEPLOYED.md](DEPLOYED.md) for actual resources, current access and remaining limits. The preparation notes below record the state before deployment.

## Original preparation status

The optional server-side Bedrock integration is implemented and tested with
controlled responses. **No successful live model invocation or AWS deployment has
been verified.** The existing local preview remains usable with demo planning.
The account's `joariam` identity can authenticate but Bedrock discovery and IAM
role inspection return AccessDenied. No new billable resources were created.

## Architecture

Browser → same-origin Node.js API → AWS CLI v2 → Amazon Bedrock Converse.
The production CLI obtains temporary credentials from a dedicated EC2 role;
never copy a personal AWS access key onto the server or into browser code.
Node.js 22+ and AWS CLI v2 are the only server runtime requirements. There is no
Node package installation/build requirement. The Python server remains an
offline-only preview; use `node server.mjs` for the AI-capable server.

The proposed model is `eu.amazon.nova-micro-v1:0`, invoked from Stockholm using
EU cross-region inference. This is **not** a guarantee that processing remains
in Sweden. Confirm account access, quotas and actual output quality before
enabling it publicly. A configured status is not a successful connection check.

## What AI actually does

- The server validates the household, meals, diet, exclusions and other inputs.
- It supplies only compatible catalogue recipe IDs to the model.
- The model generates a seven-day menu and a short Swedish explanation.
- The server rejects unknown IDs, incompatible recipes, missing/extra meals and
  malformed responses. There is no automatic retry and no silent demo fallback.
- A monthly plan repeats the seven-day menu over the actual calendar month.
- Existing deterministic code calculates quantities, pack rounding, pantry
  deductions, retailer comparisons and the shopping list. Model prices are ignored.
- An over-budget AI plan stays explicitly over budget. The model does not establish
  optimality, food safety, allergen safety or nutritional completeness.
- Recipe instructions and all grocery prices remain authored/synthetic demo data.
- The browser displays explanations as text, not executable HTML.

## Cost and abuse controls

Planning allowance, not a current quotation: 150–250 SEK/month for a small EC2
server, storage and IPv4, plus 10–30 SEK for light AI testing. Check the exact
Stockholm instance/storage prices and applicable VAT before launching. Credits
and free-tier eligibility have not been assumed. Domains, exceptional transfer,
tax changes, backups and additional AWS services can change the total.

AI is disabled by default. Enabling requires a private access code of at least
16 characters. The code is only held in browser memory, never localStorage.
There are at most 20 model attempts/day across the entire single-process app,
one request in flight, a ten-second cooldown, a 16 KiB request limit, 1,600 output
tokens and a 45-second invocation timeout. Attempts are reserved before calling
AWS, including failures, and stored in `/var/lib/matbudget/ai-usage.json` so a
service restart cannot reset the daily counter. Do not delete this state or run
multiple app processes/replicas against it; a database quota is needed for scaling.
Daily rollover uses UTC internally; it is not a user-visible timestamp.

These controls limit this endpoint's usage, **not the whole AWS bill**. Other
account users, server storage/IP charges and external model calls are outside
this counter. AWS budget alerts are warnings, not spending caps.

## Concrete AWS permissions prepared

`deploy/ec2-trust-policy.json`: only EC2 can assume `MatbudgetWebRole`.
`deploy/bedrock-role-policy.json`: only Nova Micro through the EU inference profile,
including the underlying EU foundation-model routing permissions.
`deploy/pass-app-role-policy.json`: lets `joariam` pass only this role to EC2.
These are proposed, unapplied documents for account ACCOUNT_ID_REDACTED. They do not grant
BedrockFullAccess or AdministratorAccess. Create the instance profile with the
same role name after confirming the role is new or belongs to this application.
Use a root/admin console session for role/profile creation and attaching the
scoped PassRole policy; the current CLI identity cannot inspect IAM roles.
Do not change unrelated policies or reapply old coursework Terraform.

## Deployment sequence (not yet executed)

1. Create and verify the scoped EC2 role and instance profile in this account.
2. Choose a small EC2 instance in eu-north-1, encrypted storage, IMDSv2 required,
   dedicated security group and `Project=Matbudget` tags. Check actual hourly cost
   before launch. Preserve all unrelated account resources.
3. Install Node.js 22 and AWS CLI v2. For Amazon Linux 2023, Node is namespaced
   (`nodejs22` package); confirm `/usr/bin/node-22` before using the service file.
4. Copy only `web/`, `server/`, `server.mjs` and service configuration to
   `/opt/matbudget`; create the unprivileged `matbudget` system user.
5. Store runtime settings from `.env.example` in root-owned `/etc/matbudget.env`,
   mode 0600. Generate a random access code. Set HOST=127.0.0.1 and state path as
   above. Keep AI_ENABLED=0 until the role and model invocation are verified.
6. Put a reverse proxy with trusted HTTPS in front of the loopback service. A
   domain/certificate or suitable AWS HTTPS front door still needs choosing.
   Do not expose the access-code form over public plaintext HTTP. The existing
   loopback preview needs no public certificate.
7. Enable AI, run one small live generation, verify its menu/constraints and usage
   counter, then test full UI generation, quiz, errors, shopping and mobile layout.
8. Record the real public HTTPS URL, actual resources and costs. Add a budget alert
   after the notification destination has been chosen. Document start/stop/delete
   procedures with exact new resource identifiers. Do not claim deployment complete
   before browser and live-model verification.

## Local development

`node server.mjs` starts the AI-capable server on loopback port 8787 with AI off.
Set environment variables explicitly; `.env.example` is documentation and is not
loaded automatically. On this Windows machine, BEDROCK_USE_WSL=1 can use the
existing Ubuntu AWS CLI and its credential chain. Access is still subject to IAM.
Never start a second server on the same port; inspect the existing process first.

Run `node --test tests/engine.test.mjs tests/ai.test.mjs`. The API tests inject
controlled model answers and make no billable AWS requests. They cover hard
constraints, month expansion, access protection, input checks, private-file
isolation, malformed model output and quota persistence after server restart.

## Official references

- https://docs.aws.amazon.com/bedrock/latest/APIReference/API_runtime_Converse.html
- https://docs.aws.amazon.com/bedrock/latest/userguide/model-card-amazon-nova-micro.html
- https://docs.aws.amazon.com/bedrock/latest/userguide/inference-profiles-prereq.html
- https://docs.aws.amazon.com/linux/al2023/ug/nodejs.html
- https://aws.amazon.com/ec2/pricing/on-demand/
- https://aws.amazon.com/vpc/pricing/
- https://aws.amazon.com/bedrock/pricing/
